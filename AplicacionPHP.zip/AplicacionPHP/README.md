# Apliaci-nPHP
Sistema PHP para gestionar universidades y alumnos con funciones de agregar, eliminar, editar y ver detalles. Incluye operaciones CRUD, seguridad, y diseño responsivo. Ideal para administrar información académica de manera eficiente.
